import { createClient } from '@supabase/supabase-js';

// Configuração injetada conforme solicitado
const supabaseUrl = 'https://qvkfoitbatyrwqbicwwc.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF2a2ZvaXRiYXR5cndxYmljd3djIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM2NjE5NjMsImV4cCI6MjA3OTIzNzk2M30.YzaC8z3e3ut6FFiNsr4e-NJtcVQvvLX-QuOKtjd78YM';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
