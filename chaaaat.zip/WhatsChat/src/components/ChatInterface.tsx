import { useEffect, useState, useRef } from 'react';
import { supabase } from '../services/supabaseClient';
import { Profile, Message } from '../types';
import { Send, LogOut, User as UserIcon } from 'lucide-react';

export default function ChatInterface({ session }: { session: any }) {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [selectedUser, setSelectedUser] = useState<Profile | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchProfiles();
    
    // Inscrever para mensagens em tempo real
    const channel = supabase
      .channel('public:messages')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, payload => {
        const newMsg = payload.new as Message;
        if (
          (newMsg.sender_id === session.user.id && newMsg.recipient_id === selectedUser?.id) ||
          (newMsg.sender_id === selectedUser?.id && newMsg.recipient_id === session.user.id)
        ) {
          setMessages(prev => [...prev, newMsg]);
          scrollToBottom();
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [selectedUser]);

  const fetchProfiles = async () => {
    const { data } = await supabase
      .from('profilesMSP')
      .select('*')
      .neq('id', session.user.id); // Não mostrar o próprio usuário
    if (data) setProfiles(data);
  };

  const fetchMessages = async (userId: string) => {
    const { data } = await supabase
      .from('messages')
      .select('*')
      .or(`and(sender_id.eq.${session.user.id},recipient_id.eq.${userId}),and(sender_id.eq.${userId},recipient_id.eq.${session.user.id})`)
      .order('created_at', { ascending: true });
    
    if (data) {
      setMessages(data);
      scrollToBottom();
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedUser) return;

    const { error } = await supabase.from('messages').insert({
      content: newMessage,
      sender_id: session.user.id,
      recipient_id: selectedUser.id
    });

    if (!error) {
      setNewMessage('');
    }
  };

  const scrollToBottom = () => {
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar - Lista de Contatos */}
      <div className={`w-full md:w-1/3 bg-white border-r ${selectedUser ? 'hidden md:block' : 'block'}`}>
        <div className="p-4 bg-gray-200 flex justify-between items-center border-b">
          <h1 className="font-bold text-gray-700">Contatos</h1>
          <button onClick={() => supabase.auth.signOut()} className="text-red-500">
            <LogOut size={20} />
          </button>
        </div>
        <div className="overflow-y-auto h-full">
          {profiles.map(profile => (
            <div
              key={profile.id}
              onClick={() => { setSelectedUser(profile); fetchMessages(profile.id); }}
              className="p-4 border-b hover:bg-gray-50 cursor-pointer flex items-center gap-3"
            >
              <div className="w-10 h-10 bg-gray-300 rounded-full flex items-center justify-center">
                <UserIcon className="text-gray-600" />
              </div>
              <div>
                <p className="font-semibold">{profile.username || profile.email}</p>
                <p className="text-xs text-gray-500">Toque para conversar</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Área do Chat */}
      <div className={`w-full md:w-2/3 flex flex-col ${!selectedUser ? 'hidden md:flex' : 'flex'}`}>
        {selectedUser ? (
          <>
            <div className="p-3 bg-green-700 text-white flex items-center gap-2 shadow">
              <button onClick={() => setSelectedUser(null)} className="md:hidden mr-2">←</button>
              <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center">
                <UserIcon className="text-green-700" size={18} />
              </div>
              <span className="font-bold">{selectedUser.username || selectedUser.email}</span>
            </div>

            <div className="flex-1 p-4 overflow-y-auto bg-[#e5ded8]">
              {messages.map((msg, index) => {
                const isMe = msg.sender_id === session.user.id;
                return (
                  <div key={index} className={`flex ${isMe ? 'justify-end' : 'justify-start'} mb-2`}>
                    <div className={`max-w-[70%] p-2 rounded-lg shadow ${isMe ? 'bg-[#dcf8c6]' : 'bg-white'}`}>
                      <p className="text-sm">{msg.content}</p>
                      <p className="text-[10px] text-gray-500 text-right mt-1">
                        {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            <div className="p-3 bg-gray-100 flex gap-2 items-center">
              <input
                type="text"
                className="flex-1 p-3 rounded-full border focus:outline-none"
                placeholder="Digite uma mensagem"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
              />
              <button onClick={sendMessage} className="p-3 bg-green-600 rounded-full text-white shadow">
                <Send size={20} />
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center bg-[#f0f2f5] text-gray-400">
            <p>Selecione um contato para começar</p>
          </div>
        )}
      </div>
    </div>
  );
}
