import React, { useState } from 'react';
import { saveSupabaseConfig } from '../services/supabaseClient';
import { Database, Key, Save } from 'lucide-react';

export const ConfigScreen: React.FC = () => {
  const [url, setUrl] = useState('');
  const [key, setKey] = useState('');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (url && key) saveSupabaseConfig({ url, key });
  };

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
        <h1 className="text-2xl font-bold text-center mb-2">Configuração</h1>
        <form onSubmit={handleSave} className="space-y-4">
          <input type="text" value={url} onChange={(e) => setUrl(e.target.value)} className="block w-full p-2 border rounded" placeholder="Supabase URL" required />
          <input type="password" value={key} onChange={(e) => setKey(e.target.value)} className="block w-full p-2 border rounded" placeholder="Anon Key" required />
          <button type="submit" className="w-full bg-emerald-600 text-white p-2 rounded">Salvar</button>
        </form>
      </div>
    </div>
  );
};
